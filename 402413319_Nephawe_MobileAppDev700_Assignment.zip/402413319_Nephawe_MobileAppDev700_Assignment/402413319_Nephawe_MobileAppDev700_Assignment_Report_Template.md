# Smart Pantry Manager
**Student:** Nephawe  
**Student number:** 402413319  
**Module:** Mobile App Development 700  
**Date:** [Insert date]

## Table of Contents
1. Introduction
2. System Design
3. Database Design
4. Key Code Snippets
5. Testing and Screenshots
6. Challenges and Solutions
7. Conclusion and Reflection
8. References

## 1. Introduction
Smart Pantry Manager is an Android application written in Java. It is designed to help a user record ingredients available at home and reduce food waste. It suggests a recipe only when every required ingredient and the required quantity are available in the pantry.

## 2. System Design
The main screen flow is: Pantry List → Add/Edit Ingredient; Pantry List → Suggested Recipes → Recipe Detail; Pantry List → Settings. Intents are used to move between activities and pass the selected pantry or recipe ID.

## 3. Database Design
SQLite is used through `SQLiteOpenHelper`. The `pantry` table stores an ID, ingredient name, quantity and unit. The `recipes` table stores a recipe ID, name, required ingredients and preparation method. Pantry records are stored on the device and remain after the app is closed.

## 4. Key Code Snippets
Insert 3–5 short excerpts from your own tested code and explain each one:
- Database table creation and CRUD.
- Strict recipe matching.
- Form validation.
- Intent navigation.

## 5. Testing and Screenshots
Insert real screenshots from the running application, with captions:
- Pantry list with saved items.
- Add ingredient form.
- Validation message for missing/invalid fields.
- Edit and delete operation.
- Suggested recipes with a full match.
- Recipe disappears when a required ingredient or sufficient quantity is removed.
- Recipe detail.
- Settings.
- Data still present after closing and reopening the app.

## 6. Challenges and Solutions
Describe 2–3 actual challenges you encountered while building and testing the application. Explain what you did to solve each one. Do not include problems you did not experience.

## 7. Conclusion and Reflection
Explain what you learned about Java Activities, Intents, SQLite, lists/adapters and strict recipe matching. Mention realistic improvements you would make with more time.

## 8. References
Add the sources you actually consulted in Harvard style. Example format only:
Android Developers (n.d.) *[Title of page]*. Available at: [URL] (Accessed: [date]).
